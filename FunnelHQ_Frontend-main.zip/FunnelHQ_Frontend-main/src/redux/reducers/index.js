import { combineReducers } from "redux";

import auth from "./auth"

export const reducers = combineReducers({auth})